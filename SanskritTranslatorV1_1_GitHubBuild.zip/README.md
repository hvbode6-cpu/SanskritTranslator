# Sanskrit Translator V1.1
Android prototype focused on the image-to-Sanskrit workflow.
V1.1 adds the scan/upload entry point and a cleaner OCR-ready architecture.
The actual offline Devanagari OCR engine is the next integration step.
Never embed an OpenAI API key in the APK.
Build with Android Studio: open this folder, sync Gradle, then Build > Generate APK.

## Cloud APK build
This repository includes a GitHub Actions workflow. After uploading the project to a GitHub repository, open Actions > Build Sanskrit Translator APK > Run workflow. The generated debug APK is available as a workflow artifact.
