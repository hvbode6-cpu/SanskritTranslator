plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.example.sanskrittranslator"; compileSdk=35
    defaultConfig { applicationId="com.example.sanskrittranslator"; minSdk=24; targetSdk=35; versionCode=11; versionName="1.1" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.ui:ui:1.7.8")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.8")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    debugImplementation("androidx.compose.ui:ui-tooling:1.7.8")
}
