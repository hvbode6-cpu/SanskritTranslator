package com.example.sanskrittranslator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}
}
@Composable fun App(){
 var page by remember{mutableStateOf("home")}; var text by remember{mutableStateOf("")}
 MaterialTheme{
  when(page){
   "home"->Home({page="scan"},{page="editor"})
   "scan"->Editor("📷 Scan / Upload Sanskrit",text,{text=it},{page="analysis"},{page="home"})
   "editor"->Editor("✍️ Sanskrit Text",text,{text=it},{page="analysis"},{page="home"})
   else->Analysis(text,{page="editor"})
  }
 }
}
@Composable fun Home(scan:()->Unit,type:()->Unit){
 Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
  Spacer(Modifier.height(28.dp)); Text("संस्कृत अनुवादक",style=MaterialTheme.typography.headlineLarge)
  Text("Sanskrit Translator V1.1",style=MaterialTheme.typography.titleMedium)
  Text("Image-to-text workflow prepared for offline Devanāgarī OCR.")
  Button(scan,Modifier.fillMaxWidth().height(58.dp)){Text("📷  Scan / Upload Sanskrit")}
  OutlinedButton(type,Modifier.fillMaxWidth().height(58.dp)){Text("✍️  Enter Sanskrit")}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
   Text("V1.1",style=MaterialTheme.typography.titleMedium)
   Text("• Image/OCR workflow screen")
   Text("• Editable Sanskrit text")
   Text("• Analysis workspace")
   Text("• Offline-first design")
   Text("• No API key stored in the app")
  }}
 }
}
@Composable fun Editor(title:String,text:String,onChange:(String)->Unit,analyse:()->Unit,back:()->Unit){
 Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text(title,style=MaterialTheme.typography.headlineSmall)
  Text("Next OCR module will read printed Devanāgarī directly from the selected photo.")
  OutlinedTextField(text,onChange,Modifier.fillMaxWidth().weight(1f),label={Text("संस्कृतम्")},placeholder={Text("रामः वनं गच्छति।")},textStyle=LocalTextStyle.current.copy(fontFamily=FontFamily.Serif))
  Button(analyse,Modifier.fillMaxWidth()){Text("📖 Analyse")}
  TextButton(back){Text("Back")}
 }
}
@Composable fun Analysis(text:String,back:()->Unit){
 Column(Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(12.dp)){
  Text("Analysis",style=MaterialTheme.typography.headlineSmall)
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Original Sanskrit",style=MaterialTheme.typography.titleMedium);Text(text.ifBlank{"No text entered."})}}
  val words=text.trim().split(Regex("\s+")).filter{it.isNotBlank()}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Word analysis",style=MaterialTheme.typography.titleMedium);if(words.isEmpty())Text("Enter Sanskrit text.") else words.forEachIndexed{i,w->Text("${i+1}. $w — grammar module")}}}
  Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Translation",style=MaterialTheme.typography.titleMedium);Text("AI/offline translation module will be added in the next engine build.")}}
  Text("Planned: Padaccheda • Sandhi • Samāsa • Vibhakti • Dhātu • Lakāra • Pratyaya")
  TextButton(back){Text("Edit")}
 }
}
